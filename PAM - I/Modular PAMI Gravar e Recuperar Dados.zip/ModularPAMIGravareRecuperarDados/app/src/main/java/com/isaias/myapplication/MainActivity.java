package com.isaias.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button gravar, recuperar;
    EditText nome, email, telefone, idade;
    TextView mensagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        initComponents();
        gravar.setOnClickListener(v->{
            SharedPreferences preferences = getSharedPreferences("dados.xml", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("nome", nome.getText().toString());
            editor.putString("email", email.getText().toString());
            editor.putString("telefone", telefone.getText().toString());
            editor.putString("idade", idade.getText().toString());

            editor.commit();
            Toast.makeText(this, "Dados gravados com Sucesso!", Toast.LENGTH_SHORT).show();
        });

        recuperar.setOnClickListener(v -> {
            SharedPreferences preferences = getSharedPreferences("dados.xml", MODE_PRIVATE);
            String nome, email, telefone, idade;

            nome        = preferences.getString("nome", "");
            email       = preferences.getString("email", "");
            telefone    = preferences.getString("telefone", "");
            idade       = preferences.getString("idade", "");

            mensagem.setText("Nome: " + nome + "\nTelefone: " + telefone + "\nIdade: " + idade);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initComponents() {
        gravar      = findViewById(R.id.btn_gravar);
        recuperar   = findViewById(R.id.btn_recuperar);
        nome        = findViewById(R.id.nome);
        email       = findViewById(R.id.email);
        telefone    = findViewById(R.id.telefone);
        idade       = findViewById(R.id.idade);
        mensagem    = findViewById(R.id.mensagem);
    }
}