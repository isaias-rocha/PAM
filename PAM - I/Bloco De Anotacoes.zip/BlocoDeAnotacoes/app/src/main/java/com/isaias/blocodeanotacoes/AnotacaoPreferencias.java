package com.isaias.blocodeanotacoes;

public class AnotacaoPreferencias {

    public void salvarAnotacao(){

    }
    public String recuperarAnotacao(){
        return("");
    }

}
